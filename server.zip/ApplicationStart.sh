#!/bin/bash
/opt/server
